# Fullscreen BurgerMenu
Super simple fullscreen burgermneu script that is written in HTML, CSS and vanilla JavaScript. Classes are added on click and animated with the power of CSS3.

Simply download the files and use it as you wish.
